# Aplikasi Kasir (Point Of Sale)
Aplikasi sistem penjualan berbasis web menggunakan framework codeigniter 4.
